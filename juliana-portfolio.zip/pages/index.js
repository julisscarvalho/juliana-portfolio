
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

export default function Portfolio() {
  return (
    <div className="px-6 py-12 max-w-7xl mx-auto">
      <header className="text-center mb-12">
        <h1 className="text-5xl font-extrabold mb-2">Juliana Pinto</h1>
        <p className="text-lg text-gray-600">Visual Artist, Designer & Advocate for Creative Accessibility</p>
      </header>

      <section className="mb-16 text-center">
        <h2 className="text-3xl font-bold mb-4">About Me</h2>
        <p className="text-gray-700 max-w-3xl mx-auto">
          I am a Brazilian visual artist and designer passionate about using art and communication to amplify voices and promote accessibility. With experience in brand design, lettering, social campaigns, and NGO work, I create with purpose and empathy.
        </p>
      </section>

      <section className="mb-16">
        <h2 className="text-3xl font-bold text-center mb-6">Portfolio</h2>
        <Tabs defaultValue="design">
          <TabsList className="flex justify-center gap-4">
            <TabsTrigger value="design">Design</TabsTrigger>
            <TabsTrigger value="art">Art</TabsTrigger>
            <TabsTrigger value="logos">Logos</TabsTrigger>
          </TabsList>

          <TabsContent value="design" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
            <Card>
              <CardContent className="p-4">
                <img src="/design1.jpg" alt="Design Project" className="rounded-xl" />
                <p className="mt-2 text-center">Social Campaign – La Fleur Bistro</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="art" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
            <Card>
              <CardContent className="p-4">
                <img src="/art1.jpg" alt="Calligraphy" className="rounded-xl" />
                <p className="mt-2 text-center">Hand Lettering for NGOs and Clients</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="logos" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
            <Card>
              <CardContent className="p-4">
                <img src="/logo1.jpg" alt="Logo Design" className="rounded-xl" />
                <p className="mt-2 text-center">Branding – La Fleur Bistro</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </section>

      <section className="text-center">
        <h2 className="text-3xl font-bold mb-4">Contact</h2>
        <p className="text-gray-700">Get in touch via email at <a href="mailto:juliana.pinto0302@gmail.com" className="text-blue-600 underline">juliana.pinto0302@gmail.com</a></p>
      </section>
    </div>
  );
}
